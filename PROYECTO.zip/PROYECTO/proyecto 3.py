from tkinter import *
import time

ventana = Tk()
ventana.title("FateBall")
ventana.resizable(False,False)

canvas = Canvas(ventana,width=900,height=600)
canvas.pack()

imagen = PhotoImage(file = "menu2.gif")
canvas.create_image(0,0,image = imagen,anchor=NW)

#funciones botones

def quit(v):
    v.destroy() 

def fuera():
    quit(ventana)
    import proyecto_2

#botones
jugari = PhotoImage(file = 'image.gif')
bjugar = Button(ventana, text = "Jugar", image = jugari, command = fuera).place(x=200, y=380)
saliri = PhotoImage(file = 'image2.gif')
bsalir = Button(ventana, text = "Jugar", image = saliri, command = fuera).place(x=550, y=380)   


