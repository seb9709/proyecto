from tkinter import *
import time
import random

#crear menu
menu = Tk()
menu.title("FateBall")
menu.resizable(False,False)
canvas = Canvas(menu,width=900,height=600)
canvas.pack()

#fondo menu
imagen = PhotoImage(file = "menu2.gif")
canvas.create_image(0,0,image = imagen,anchor=NW)

#cerrar menu

def fuera():
    return quit() 


#crear juego juego

def juego():

#ventana del juego
    
    menu.destroy()
    ventana = Tk()
    ventana.resizable(False,False)
    canvas = Canvas(ventana,width=800,height=800)
    canvas.pack()

#fondo del juego
    imagen = PhotoImage(file = "pinball.gif")
    canvas.create_image(0,0,image = imagen,anchor=NW)

#crear cuadricula de canvas
    
    '''#cuadricula para los canvas
    def cuadricula(canvas, line_distance):
        for x in range(line_distance,800,line_distance):
            canvas.create_line(x,0,x, 800, fill = "red")

        for y in range(line_distance,800,line_distance):
            canvas.create_line(0,y, 800, y, fill = "red")

    cuadricula(canvas,100)'''


#canvas de lineas exteriores

    canvas.create_line(740,800,740,200,width = 4,fill = "white")
    canvas.create_line(798,150,798,800,width = 4,fill = "white")
    canvas.create_line(154,798,800,798,width = 4,fill = "white")
    canvas.create_line(154,800,154,155,width = 4,fill = "white")
    canvas.create_line(750,3,240,3,width = 4,fill = "white")


#canvas de lineas interiores-obstaculos
    canvas.create_line(224,158,300,50,width = 6,fill = "red")
    canvas.create_line(224,158,224,600,width = 6,fill = "red")
    canvas.create_line(680,600,680,200,width = 6,fill = "red")

#canvas de poligonos
    canvas.create_polygon(300,800,260,700,152,650,152,800,fill="white")
    canvas.create_polygon(590,800,620,700,740,650,740,800,fill="white")
    canvas.create_polygon(152,161,255,0,152,0,fill="white")
    canvas.create_polygon(800,160,700,0,800,0,fill="white")
    canvas.create_polygon(224,600,350,670,300,450,224,400,fill="red")
    canvas.create_polygon(680,600,560,670,600,500,680,450,fill="red")
    canvas.create_polygon(450,550,400,500,450,420,500,500,outline="red",fill="white",width=4)

#canvas de bolas
    canvas.create_oval(592,108,508,192, outline="red",fill="white",width=15)
    canvas.create_oval(392,208,309,292, outline="red",fill="white",width=15)
    canvas.create_oval(590,308,508,392, outline="red",fill="white",width=15)

#canvas de paletas
    paleta1 = canvas.create_polygon(350,670,380,660,434,670,380,680,outline="red",fill="white",width=2)
    paleta2 = canvas.create_polygon(560,670,530,660,476,670,530,680,outline="red",fill="white",width=2)






#revote de la bola en los otros canvas

    def moveball():
       
        x1, y1, x2, y2 = canvas.coords(pelota["obj"])
        x = (x1 + x2) // 2
        y = (y1 + y2) // 2

        revote = canvas.find_overlapping(x1, y1, x2, y2)
        print (revote)
        
        if x < 10 or x > 800:
            pelota["dx"] *= -1
        if y < 10 or y > 800:
            pelota["dy"] *= -1

        if revote == (1, 13, 22): # Elemento de salida
            pelota["dx"] = -6 
            pelota["dy"] = -1 

        if revote == (1, 17, 22): # primera bola de choque
            pelota["dx"] = 2
            pelota["dy"] = 6

        if revote == (1, 9, 22): # borde interno derecho rojo
            pelota["dx"] = -2
            pelota["dy"] = 4

        if revote == (1, 15, 22): # borde interno izquierdo rojo
            pelota["dx"] = -3
            pelota["dy"] = 2

        if revote == (1, 2, 22): # exterior blanco
            pelota["dx"] = -2
            pelota["dy"] = -2

        if revote == (1, 1, 22): # borde interno derecho blanco 
            pelota["dx"] = -1
            pelota["dy"] = 2

        if revote == (1, 16, 22): # borde interno izquierdo rojo
            pelota["dx"] = -2
            pelota["dy"] = -2

        if revote == (1, 19, 22): # bola de abajo
            pelota["dx"] = 2
            pelota["dy"] = 0

        if revote == (1, 18, 22): # bola de arriba
            pelota["dx"] = 2
            pelota["dy"] = 0

        if revote == (1, 11, 22): # borde interno derecho arriba blanco
            pelota["dx"] = -1
            pelota["dy"] = -2

        if revote == (1, 10, 22): # borde interno izquierdo blanco
            pelota["dx"] = 1
            pelota["dy"] = -2

        if revote == (1, 5, 22): # borde interno derecho blanco
            pelota["dx"] = 1
            pelota["dy"] = -2

        if revote == (1, 9, 5, 22): # borde interno derecho rojo
            pelota["dx"] = -1
            pelota["dy"] = -2

        if revote == (1, 14, 22): # borde interno izquierdo rojo
            pelota["dx"] = 2
            pelota["dy"] = -2

        if revote == (1, 22, 22):  
            pelota["dx"] = -2
            pelota["dy"] = -2









#revote en las paletas

        if revote == (1, 20, 22) or revote == (1, 20, 24) or revote == (1, 20, 26) or revote == (1, 20, 28): #paleta 1 - izquiera 
            pelota["dx"] = -2
            pelota["dy"] = -5

        if revote == (1, 21, 22):  #paleta 2 - derecha
            pelota["dx"] = -2
            pelota["dy"] = -5 

    
# mover la bola y aplicar gravedad        
                   
        canvas.move(pelota["obj"],pelota["dx"],pelota["dy"])
        ventana.after(10,moveball)
        pelota["dy"] += 0.08 
        

    pelota  = {"dx":0 , "dy": -10, "obj": canvas.create_oval(754,746,782,774, outline="white",fill="red",width=2)}

#control de la bola

    def correr(event):
        
        tecla = repr(event.char)
        if (tecla == "'v'"):
            moveball()


#movimiento de las paletas

    def movimiento1(event):
          
            
            global canvas,paleta1        
            tecla = repr(event.char)
            if(tecla == "'a'"):            
                canvas.delete(paleta1)        
                paleta1 = canvas.create_polygon(350,670,370,650,424,640,380,670,outline="red",fill="white",width=2)
                canvas.update()
                canvas.delete(paleta1)
                time.sleep(0.15)
                paleta1 = canvas.create_polygon(350,670,380,660,434,670,380,680,outline="red",fill="white",width=2)
                canvas.after(100)

    def movimiento2(event):
            
            global canvas,paleta2        
            tecla2 = repr(event.char)
            if(tecla2 == "'d'"):            
                canvas.delete(paleta2)        
                paleta2 = canvas.create_polygon(560,670,540,650,476,640,530,670,outline="red",fill="white",width=2)
                canvas.update()
                canvas.delete(paleta2)
                time.sleep(0.15)
                paleta2 = canvas.create_polygon(560,670,530,660,476,670,530,680,outline="red",fill="white",width=2)
                canvas.after(100)
                
                
    canvas.bind("v",correr)  
    canvas.bind("a",movimiento1)
    canvas.bind("d",movimiento2)
    canvas.focus_set()
    
#salir del juego
    
    def salir():
        ventana.destroy()

#boton salir juego

    salirjuego = PhotoImage(file = 'image2.gif')
    bsalirjuego = Button(ventana, image = salirjuego, command = salir).place(x=7, y=735)  
    ventana.mainloop()



#botones del menu
    
jugari = PhotoImage(file = 'image.gif')
bjugar = Button(menu, image = jugari, command = juego).place(x=200, y=380)
saliri = PhotoImage(file = 'image2.gif')
bsalir = Button(menu, image = saliri, command = fuera).place(x=550, y=380)   



