from tkinter import *
import time
#ventana
ventana = Tk()
ventana.title("FateBall")
ventana.resizable(False,False)
canvas = Canvas(ventana,width=900,height=600)
canvas.pack()

#fondo
imagen = PhotoImage(file = "menu2.gif")
canvas.create_image(0,0,image = imagen,anchor=NW)

#funciones botones

def fuera():
    return quit() 

def abrejuego():
    ventana.destroy()
    import proyecto_2

#botones
jugari = PhotoImage(file = 'image.gif')
bjugar = Button(ventana, text = "Jugar", image = jugari, command = abrejuego).place(x=200, y=380)
saliri = PhotoImage(file = 'image2.gif')
bsalir = Button(ventana, text = "Jugar", image = saliri, command = fuera).place(x=550, y=380)   


